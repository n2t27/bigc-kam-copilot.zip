"""
Big C KAM copilot - a small, self-contained example of the Claude API
applied to Key Account Management.

What it does
  review : Python calculates week-on-week sell-out by SKU and store, then
           Claude writes the account review (headline, risks, actions)
           using only those numbers and the trading terms (TTA).
  ask    : Claude answers free questions and fetches the data it needs
           through tools (the agent loop from the course).

Run it
  python kam_copilot.py review --offline            # no API key needed
  python kam_copilot.py review --week 2026-W39      # needs ANTHROPIC_API_KEY
  python kam_copilot.py ask "Why did fish sauce drop at HCM-02 in 2026-W39?"

Everything this file needs is defined in this file or read from ./data,
so there are no variables to set up by hand before running it.
All figures in ./data are sample data, not real Big C data.
"""

import argparse
import csv
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. Settings. Paths are built from this file's location, so the script works
#    no matter which folder you run it from.
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
SALES_CSV = BASE_DIR / "data" / "bigc_sellout_sample.csv"
TTA_FILE = BASE_DIR / "data" / "bigc_tta_sample.txt"

try:  # python-dotenv is optional; it reads ANTHROPIC_API_KEY from .env
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass

MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")  # change in .env if needed
MAX_TOKENS = 2000
CHANGE_THRESHOLD_PCT = 10.0   # flag a SKU or store if units move more than this
OOS_THRESHOLD_DAYS = 3        # TTA clause 5.3: 3+ out-of-stock days triggers a review


# ---------------------------------------------------------------------------
# 2. Data layer: plain Python, no AI. Numbers must be exact, so code does them.
# ---------------------------------------------------------------------------
def load_sales(path=SALES_CSV):
    """Read the sell-out CSV into a list of dicts with proper number types."""
    if not path.exists():
        raise FileNotFoundError(f"Sales file not found: {path}")
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            r["units"] = int(r["units"])
            r["net_sales_vnd"] = int(r["net_sales_vnd"])
            r["on_promo"] = int(r["on_promo"])
            r["oos_days"] = int(r["oos_days"])
            rows.append(r)
    return rows


def load_tta(path=TTA_FILE):
    if not path.exists():
        raise FileNotFoundError(f"Trading terms file not found: {path}")
    return path.read_text(encoding="utf-8")


def list_weeks(rows):
    return sorted({r["week"] for r in rows})


def pct_change(new, old):
    if old == 0:
        return None
    return round((new - old) / old * 100, 1)


def query_sales(rows, week, sku="", store=""):
    """Return raw rows for one week, optionally filtered by SKU and/or store."""
    if week not in list_weeks(rows):
        raise ValueError(f"No data for week {week}. Available weeks: {list_weeks(rows)}")
    out = [r for r in rows if r["week"] == week
           and (not sku or r["sku"] == sku)
           and (not store or r["store"] == store)]
    if not out:
        raise ValueError(f"No rows for week={week}, sku={sku or 'any'}, store={store or 'any'}")
    return out


def compare_weeks(rows, week):
    """Week-on-week comparison by SKU and by store, plus the flags a KAM cares about."""
    weeks = list_weeks(rows)
    if week not in weeks:
        raise ValueError(f"No data for week {week}. Available weeks: {weeks}")
    idx = weeks.index(week)
    if idx == 0:
        raise ValueError(f"{week} is the first week in the file, there is no previous week to compare.")
    prev = weeks[idx - 1]

    def totals(key):
        t = defaultdict(lambda: {"units": 0, "net_sales_vnd": 0})
        for r in rows:
            if r["week"] in (week, prev):
                t[(r[key], r["week"])]["units"] += r["units"]
                t[(r[key], r["week"])]["net_sales_vnd"] += r["net_sales_vnd"]
        return t

    names = {r["sku"]: r["sku_name"] for r in rows}
    promo_prev = {r["sku"] for r in rows if r["week"] == prev and r["on_promo"]}
    promo_now = {r["sku"] for r in rows if r["week"] == week and r["on_promo"]}

    by_sku, t = [], totals("sku")
    for sku in sorted(names):
        a, b = t[(sku, prev)], t[(sku, week)]
        by_sku.append({
            "sku": sku, "sku_name": names[sku],
            "units_prev": a["units"], "units_now": b["units"],
            "units_change_pct": pct_change(b["units"], a["units"]),
            "sales_now_vnd": b["net_sales_vnd"],
            "promo_prev_week": sku in promo_prev, "promo_this_week": sku in promo_now,
        })

    stores = sorted({r["store"] for r in rows})
    by_store, t = [], totals("store")
    for s in stores:
        a, b = t[(s, prev)], t[(s, week)]
        by_store.append({"store": s, "units_prev": a["units"], "units_now": b["units"],
                         "units_change_pct": pct_change(b["units"], a["units"])})

    oos_alerts = [{"store": r["store"], "sku": r["sku"], "sku_name": r["sku_name"],
                   "oos_days": r["oos_days"]}
                  for r in rows if r["week"] == week and r["oos_days"] >= OOS_THRESHOLD_DAYS]

    total_prev = sum(x["units_prev"] for x in by_sku)
    total_now = sum(x["units_now"] for x in by_sku)
    flags = [x for x in by_sku
             if x["units_change_pct"] is not None and abs(x["units_change_pct"]) >= CHANGE_THRESHOLD_PCT]

    return {
        "week": week, "previous_week": prev,
        "total_units_prev": total_prev, "total_units_now": total_now,
        "total_units_change_pct": pct_change(total_now, total_prev),
        "total_sales_now_vnd": sum(x["sales_now_vnd"] for x in by_sku),
        "by_sku": by_sku, "by_store": by_store,
        "skus_moving_more_than_threshold": flags,
        "oos_alerts": oos_alerts,
        "thresholds": {"change_pct": CHANGE_THRESHOLD_PCT, "oos_days": OOS_THRESHOLD_DAYS},
    }


def print_facts(facts):
    """Readable table in the terminal. Works without any API key."""
    print(f"\nBig C sell-out  {facts['previous_week']} -> {facts['week']}  (sample data)")
    print(f"Total units: {facts['total_units_prev']:,} -> {facts['total_units_now']:,} "
          f"({facts['total_units_change_pct']:+.1f}%)")
    print("\nBy SKU")
    print(f"  {'SKU':<9} {'Name':<22} {'Prev':>7} {'Now':>7} {'Chg%':>7}  Promo")
    for x in facts["by_sku"]:
        chg = "n/a" if x["units_change_pct"] is None else f"{x['units_change_pct']:+.1f}"
        promo = ("prev " if x["promo_prev_week"] else "") + ("now" if x["promo_this_week"] else "")
        print(f"  {x['sku']:<9} {x['sku_name']:<22} {x['units_prev']:>7,} {x['units_now']:>7,} {chg:>7}  {promo}")
    print("\nBy store")
    for x in facts["by_store"]:
        chg = "n/a" if x["units_change_pct"] is None else f"{x['units_change_pct']:+.1f}%"
        print(f"  {x['store']:<8} {x['units_prev']:>7,} -> {x['units_now']:>7,}  {chg}")
    print(f"\nOut-of-stock alerts (>= {OOS_THRESHOLD_DAYS} days)")
    if not facts["oos_alerts"]:
        print("  none")
    for a in facts["oos_alerts"]:
        print(f"  {a['store']} {a['sku']} {a['sku_name']}: {a['oos_days']} days")


# ---------------------------------------------------------------------------
# 3. Claude layer
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are a senior Key Account Management copilot for the Big C account
at a consumer goods distributor in Vietnam.
Rules:
- Use only the numbers given in the facts or returned by tools. Never invent data.
- If something needed is missing, say exactly what is missing.
- Flag abnormalities (drops, out-of-stock, promo effects) before recommending actions.
- Quote the TTA clause number when a finding relates to the trading terms.
- Write for a busy KAM: short sentences, numbers first."""


def get_client():
    """Return an Anthropic client, or None when no key is set (offline mode)."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        return None
    try:
        from anthropic import Anthropic
    except ImportError:
        sys.exit("The 'anthropic' package is missing. Run: pip install -r requirements.txt")
    return Anthropic()


def text_of(response):
    """Join all text blocks. A reply can contain several block types."""
    return "".join(b.text for b in response.content if getattr(b, "type", "") == "text")


def extract_json(text):
    """Pull the first {...} object out of Claude's reply, even if wrapped in ```json fences."""
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None


def run_review(client, rows, tta, week):
    facts = compare_weeks(rows, week)
    print_facts(facts)
    if client is None:
        print("\n[offline] Set ANTHROPIC_API_KEY in .env to get Claude's written review.")
        return facts, None

    # The TTA goes first with a cache breakpoint: it is the same on every call.
    # (Caching only activates above ~1024 tokens; the sample TTA is shorter, which is fine.)
    content = [
        {"type": "text", "text": f"<trading_terms>\n{tta}\n</trading_terms>",
         "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": f"""<facts>
{json.dumps(facts, ensure_ascii=False, indent=2)}
</facts>

Write the weekly Big C account review for {week}.
Return only a JSON object with these keys:
  "headline": one sentence with the most important number,
  "risks": list of objects {{"issue", "evidence", "tta_clause"}},
  "actions": list of objects {{"action", "owner", "due"}},
  "buyer_email_draft": a short email to the Big C buyer (plain text, no markdown)."""},
    ]
    response = client.messages.create(
        model=MODEL, max_tokens=MAX_TOKENS, system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": content}],
    )
    raw = text_of(response)
    review = extract_json(raw)
    print("\n=== Claude review ===")
    if review is None:
        print("(Could not parse JSON, showing the raw reply)\n" + raw)
    else:
        print(json.dumps(review, ensure_ascii=False, indent=2))
    return facts, review


# ---- Tools for the agent ---------------------------------------------------
TOOLS = [
    {"name": "list_weeks",
     "description": "List the ISO weeks available in the Big C sell-out data.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "query_sales",
     "description": "Raw Big C sell-out rows for one ISO week. Optional filters by SKU and store. "
                    "Each row has units, net_sales_vnd, on_promo (0/1) and oos_days.",
     "input_schema": {"type": "object", "properties": {
         "week": {"type": "string", "description": "ISO week, e.g. 2026-W39"},
         "sku": {"type": "string", "description": "Optional SKU code, e.g. SKU-1002"},
         "store": {"type": "string", "description": "Optional store code, e.g. HCM-02"}},
         "required": ["week"]}},
    {"name": "compare_weeks",
     "description": "Week-on-week comparison for one ISO week versus the previous week: "
                    "totals, by SKU, by store, SKUs moving more than 10%, out-of-stock alerts.",
     "input_schema": {"type": "object", "properties": {
         "week": {"type": "string", "description": "ISO week, e.g. 2026-W39"}},
         "required": ["week"]}},
    {"name": "get_trading_terms",
     "description": "Full text of the Big C trading terms agreement (TTA) with clause numbers.",
     "input_schema": {"type": "object", "properties": {}}},
]


def run_tool(name, args, rows, tta):
    if name == "list_weeks":
        return list_weeks(rows)
    if name == "query_sales":
        return query_sales(rows, args["week"], args.get("sku", ""), args.get("store", ""))
    if name == "compare_weeks":
        return compare_weeks(rows, args["week"])
    if name == "get_trading_terms":
        return tta
    raise ValueError(f"Unknown tool: {name}")


def run_ask(client, rows, tta, question, max_turns=8):
    if client is None:
        print("[offline] The ask command needs ANTHROPIC_API_KEY in .env.")
        return None
    messages = [{"role": "user", "content": question}]
    for _ in range(max_turns):  # guard so a confused loop cannot run forever
        response = client.messages.create(
            model=MODEL, max_tokens=MAX_TOKENS, system=SYSTEM_PROMPT,
            tools=TOOLS, messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})
        if response.stop_reason != "tool_use":
            answer = text_of(response)
            print("\n=== Answer ===\n" + answer)
            return answer

        results = []
        for block in response.content:
            if getattr(block, "type", "") != "tool_use":
                continue
            try:
                output = run_tool(block.name, block.input, rows, tta)
                results.append({"type": "tool_result", "tool_use_id": block.id,
                                "content": json.dumps(output, ensure_ascii=False)})
                print(f"  [tool] {block.name}({json.dumps(block.input)}) ok")
            except Exception as e:  # send the error back so Claude can correct itself
                results.append({"type": "tool_result", "tool_use_id": block.id,
                                "content": f"Error: {e}", "is_error": True})
                print(f"  [tool] {block.name}({json.dumps(block.input)}) error: {e}")
        messages.append({"role": "user", "content": results})

    print("Stopped after the maximum number of tool rounds.")
    return None


# ---------------------------------------------------------------------------
# 4. Command line
# ---------------------------------------------------------------------------
def main(argv=None):
    try:  # Windows consoles can choke on characters like "→" in Claude's reply
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Big C KAM copilot (sample data)")
    sub = parser.add_subparsers(dest="command", required=True)
    p_review = sub.add_parser("review", help="weekly account review")
    p_review.add_argument("--week", default=None, help="ISO week, default = latest in the file")
    p_review.add_argument("--offline", action="store_true", help="skip Claude, show numbers only")
    p_ask = sub.add_parser("ask", help="ask a free question, Claude uses tools")
    p_ask.add_argument("question")
    args = parser.parse_args(argv)

    try:
        rows = load_sales()
        tta = load_tta()
        client = None if getattr(args, "offline", False) else get_client()
        if args.command == "review":
            week = args.week or list_weeks(rows)[-1]
            run_review(client, rows, tta, week)
        elif args.command == "ask":
            run_ask(client, rows, tta, args.question)
    except (ValueError, FileNotFoundError) as e:
        sys.exit(f"Error: {e}")
    except Exception as e:  # API problems: wrong key, unknown model, no internet
        if type(e).__module__.startswith("anthropic"):
            sys.exit(f"Claude API error ({type(e).__name__}): {e}\n"
                     "Check ANTHROPIC_API_KEY and CLAUDE_MODEL in .env (see README, Common errors).")
        raise


if __name__ == "__main__":
    main()
