"""
Big C KAM MCP server (sample data).

Exposes the same data as kam_copilot.py through MCP, so any MCP client
(MCP Inspector, Claude Code, your own client) can use it.

Needs the 1.x Python SDK:  pip install "mcp[cli]<2"

Test in the browser:
  npx -y @modelcontextprotocol/inspector python bigc_mcp_server.py
Add to Claude Code:
  claude mcp add bigc -- python /full/path/to/bigc_mcp_server.py

Do not add print() calls here: with the stdio transport, stdout carries the
protocol messages and any stray print breaks the connection.
"""

import sys

try:
    from mcp.server.fastmcp import FastMCP
    from mcp.server.fastmcp.prompts import base
except ImportError:
    sys.stderr.write('This server needs the MCP Python SDK 1.x. Run: pip install "mcp[cli]<2"\n')
    sys.exit(1)

from pydantic import Field

import kam_copilot as kc  # reuse the data layer, so both files always agree

ROWS = kc.load_sales()
TTA = kc.load_tta()

mcp = FastMCP("bigc-kam", log_level="ERROR")


# ---- Tools: Claude decides when to call them --------------------------------
@mcp.tool(name="query_sales",
          description="Raw Big C sell-out rows for one ISO week, optionally filtered by SKU and store.")
def query_sales(
    week: str = Field(description="ISO week, e.g. 2026-W39"),
    sku: str = Field(default="", description="Optional SKU code, e.g. SKU-1002"),
    store: str = Field(default="", description="Optional store code, e.g. HCM-02"),
):
    return kc.query_sales(ROWS, week, sku, store)


@mcp.tool(name="compare_weeks",
          description="Compare one ISO week with the previous week: totals, by SKU, by store, "
                      "SKUs moving more than 10%, out-of-stock alerts.")
def compare_weeks(week: str = Field(description="ISO week, e.g. 2026-W39")):
    return kc.compare_weeks(ROWS, week)


@mcp.tool(name="draft_email",
          description="Prepare an email to the Big C buyer for the KAM to review. It is NOT sent.")
def draft_email(
    to: str = Field(description="Recipient email address"),
    subject: str = Field(description="Subject line"),
    body: str = Field(description="Plain-text body"),
):
    # Return every detail so Claude and the KAM can check the draft before anything goes out.
    return {"status": "draft - waiting for KAM approval, not sent",
            "to": to, "subject": subject, "body": body,
            "word_count": len(body.split())}


# ---- Resources: the app inserts them (for example on an @ mention) -----------
@mcp.resource("bigc://weeks", mime_type="application/json")
def weeks() -> list[str]:
    return kc.list_weeks(ROWS)


@mcp.resource("bigc://tta", mime_type="text/plain")
def trading_terms() -> str:
    return TTA


# ---- Prompt: the KAM picks it (for example as a / command) -------------------
@mcp.prompt(name="weekly_review", description="Standard Monday review of the Big C account.")
def weekly_review(week: str = Field(description="ISO week to review, e.g. 2026-W39")) -> list[base.Message]:
    return [base.UserMessage(f"""Review the Big C account for <week>{week}</week>.
1. Call compare_weeks for this week.
2. List every SKU that moved more than 10% and every out-of-stock alert, with the numbers.
3. Check the findings against the trading terms below and quote clause numbers.
<trading_terms>
{TTA}
</trading_terms>
4. Call draft_email with a short note to the buyer covering the top three points.
Use only numbers returned by the tools.""")]


if __name__ == "__main__":
    mcp.run(transport="stdio")
