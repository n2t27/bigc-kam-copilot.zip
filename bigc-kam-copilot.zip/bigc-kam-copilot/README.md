# Big C KAM copilot (Claude API sample project)

A small working example of the Claude API applied to Key Account Management.
Python calculates the sell-out numbers. Claude reads those numbers and the
trading terms, then writes the weekly account review, answers questions and
drafts the email to the buyer.

All data in `data/` is sample data made for this project. It is not real Big C data.

## Files

| File | What it is |
|---|---|
| `kam_copilot.py` | The copilot: weekly review + question answering with tools |
| `bigc_mcp_server.py` | The same data exposed as an MCP server |
| `selftest.py` | Checks everything without an API key or internet |
| `data/bigc_sellout_sample.csv` | 4 weeks x 4 stores x 5 SKUs of sample sell-out |
| `data/bigc_tta_sample.txt` | Sample trading terms with clause numbers |
| `.env.example` | Template for your API key |

## Setup (Windows, 5 minutes)

1. Install Python 3.10 or newer.
2. Open a terminal **inside this folder** and run:

   ```
   pip install -r requirements.txt
   python selftest.py
   ```

   Every line should start with `OK`. If so, the project is installed correctly.

3. Copy `.env.example` to `.env` and paste your key from https://platform.claude.com

   ```
   copy .env.example .env
   notepad .env
   ```

## Run

```
python kam_copilot.py review --offline
python kam_copilot.py review --week 2026-W39
python kam_copilot.py ask "Why did fish sauce drop at HCM-02 in 2026-W39, and which TTA clause applies?"
```

`--offline` shows the numbers without calling Claude, so you can test before you have a key.

### From Jupyter

Put the notebook in this folder, then:

```
%pip install -r requirements.txt
!python selftest.py
!python kam_copilot.py review --week 2026-W39
```

Or import the functions directly:

```python
import kam_copilot as kc
rows = kc.load_sales()
facts = kc.compare_weeks(rows, "2026-W39")
kc.print_facts(facts)
```

### MCP server

Test it in the browser (needs Node.js):

```
npx -y @modelcontextprotocol/inspector python bigc_mcp_server.py
```

Add it to Claude Code (use the full path to the file):

```
claude mcp add bigc -- python C:\full\path\to\bigc_mcp_server.py
```

## Use your own data

Replace `data/bigc_sellout_sample.csv` with an export that has the same columns:

```
week,store,city,sku,sku_name,units,net_sales_vnd,on_promo,oos_days
```

Replace `data/bigc_tta_sample.txt` with your own terms (plain text). Remove
anything confidential before sending data to any external service, and follow
your company's policy on customer data.

## Common errors

| Error | Cause | Fix |
|---|---|---|
| `NameError: name '...' is not defined` | Running a snippet from a tutorial on its own | Run the whole file with `python kam_copilot.py ...`; every variable is defined inside it |
| `FileNotFoundError: Sales file not found` | The `data` folder was moved | Keep `data/` next to `kam_copilot.py` |
| `No module named 'mcp.server.fastmcp'` | MCP SDK 2.x is installed | `pip install "mcp[cli]<2"` |
| `No module named 'anthropic'` | Packages installed into a different Python | Run `python -m pip install -r requirements.txt` with the same `python` you run the script with |
| `401 authentication_error` | Key missing or wrong in `.env` | Check `.env` has the full key on one line: `ANTHROPIC_API_KEY=sk-ant-...` |
| `404 not_found_error` for the model | Model name changed | Set `CLAUDE_MODEL` in `.env` to a current model name |
| `[offline] Set ANTHROPIC_API_KEY...` | No key found | Create `.env` as in step 3 |
