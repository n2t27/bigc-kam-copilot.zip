"""
Self-test: checks the whole project without an API key and without internet.

  python selftest.py

It runs the data layer, the review and the agent loop against a fake Claude
client, and (if mcp<2 is installed) starts the MCP server and calls it.
If every line ends with OK, the project is set up correctly.
"""

import asyncio
import json
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import kam_copilot as kc

BASE_DIR = Path(__file__).resolve().parent


def check(label, condition):
    print(f"{'OK  ' if condition else 'FAIL'} {label}")
    if not condition:
        sys.exit(1)


class FakeMessages:
    """Plays back scripted replies in the same shape as the real SDK."""
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self.replies.pop(0)


def text_block(t):
    return NS(type="text", text=t)


def tool_block(i, name, inp):
    return NS(type="tool_use", id=i, name=name, input=inp)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    rows = kc.load_sales()
    tta = kc.load_tta()
    check("sales file loads (80 rows)", len(rows) == 80)
    check("weeks found", kc.list_weeks(rows) == ["2026-W36", "2026-W37", "2026-W38", "2026-W39"])

    facts = kc.compare_weeks(rows, "2026-W39")
    fish = next(x for x in facts["by_sku"] if x["sku"] == "SKU-1002")
    check("fish sauce flagged as a mover", any(x["sku"] == "SKU-1002" for x in facts["skus_moving_more_than_threshold"]))
    check("out-of-stock alert at HCM-02", any(a["store"] == "HCM-02" and a["sku"] == "SKU-1002" for a in facts["oos_alerts"]))
    check("fish sauce change is negative", fish["units_change_pct"] < 0)

    try:
        kc.compare_weeks(rows, "2026-W36")
        check("first week has no previous week -> error", False)
    except ValueError:
        check("first week has no previous week -> error", True)

    # Offline review prints numbers and does not crash
    kc.run_review(None, rows, tta, "2026-W39")
    check("offline review runs", True)

    # Review with a fake Claude reply wrapped in ```json fences
    reply = '```json\n{"headline": "test", "risks": [], "actions": [], "buyer_email_draft": "hi"}\n```'
    fake = NS(messages=FakeMessages([NS(content=[text_block(reply)], stop_reason="end_turn")]))
    _, review = kc.run_review(fake, rows, tta, "2026-W39")
    check("review JSON parsed from fenced reply", review and review["headline"] == "test")
    first = fake.messages.calls[0]["messages"][0]["content"][0]
    check("TTA block carries cache_control", first.get("cache_control") == {"type": "ephemeral"})

    # Agent loop: one good tool call, one bad tool call, then a final answer
    script = [
        NS(stop_reason="tool_use", content=[
            text_block("Let me check."),
            tool_block("t1", "compare_weeks", {"week": "2026-W39"}),
            tool_block("t2", "query_sales", {"week": "2030-W01"}),
        ]),
        NS(stop_reason="end_turn", content=[text_block("Fish sauce fell because HCM-02 was out of stock 4 days.")]),
    ]
    fake = NS(messages=FakeMessages(script))
    answer = kc.run_ask(fake, rows, tta, "Why did fish sauce drop?")
    results = fake.messages.calls[1]["messages"][2]["content"]  # user turn holding the tool results
    check("agent returns final answer", answer and "HCM-02" in answer)
    check("tool_result ids match tool_use ids", [r["tool_use_id"] for r in results] == ["t1", "t2"])
    check("bad tool call returned as is_error", results[1].get("is_error") is True)
    json.loads(results[0]["content"])
    check("tool result is valid JSON text", True)

    # MCP server (optional)
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
    except ImportError:
        print('SKIP MCP server test (install with: pip install "mcp[cli]<2")')
        return

    async def mcp_test():
        params = StdioServerParameters(command=sys.executable, args=[str(BASE_DIR / "bigc_mcp_server.py")])
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as s:
                await s.initialize()
                tools = [t.name for t in (await s.list_tools()).tools]
                check("MCP tools listed", {"query_sales", "compare_weeks", "draft_email"} <= set(tools))
                res = await s.call_tool("compare_weeks", {"week": "2026-W39"})
                check("MCP compare_weeks works", not res.isError and "SKU-1002" in res.content[0].text)
                bad = await s.call_tool("query_sales", {"week": "2030-W01"})
                check("MCP bad week returns an error", bad.isError)
                r = await s.read_resource("bigc://tta")
                check("MCP resource bigc://tta", "Display" in r.contents[0].text)
                p = await s.get_prompt("weekly_review", {"week": "2026-W39"})
                check("MCP prompt weekly_review", "2026-W39" in p.messages[0].content.text)

    asyncio.run(mcp_test())
    print("\nAll checks passed.")


if __name__ == "__main__":
    main()
